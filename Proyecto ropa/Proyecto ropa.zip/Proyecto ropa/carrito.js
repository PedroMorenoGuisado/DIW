var boton1 = document.getElementById("boton1");
var boton2 = document.getElementById("boton2");
var boton3 = document.getElementById("boton3");
var boton4 = document.getElementById("boton4");
var boton5 = document.getElementById("boton5");
var boton6 = document.getElementById("boton6");
var boton7 = document.getElementById("boton7");
var boton8 = document.getElementById("boton8");
var boton9 = document.getElementById("boton9");
var boton10 = document.getElementById("boton10");
var boton11 = document.getElementById("boton11");
var boton12 = document.getElementById("boton12");

document.getElementById('boton1').addEventListener("click", function(){
  
   if(boton2.classList.contains("active")){
      boton2.classList.remove("active");
   }
  
   if(!boton1.classList.contains("active")){
      boton1.classList.toggle("active");
   }
   if(boton3.classList.contains("active")){
    boton3.classList.remove("active");
 }
   if(boton4.classList.contains("active")){
    boton4.classList.remove("active");
 }
  if(boton5.classList.contains("active")){
    boton5.classList.remove("active");
 }
 if(boton6.classList.contains("active")){
    boton6.classList.remove("active");
 } 
 if(boton7.classList.contains("active")){
    boton7.classList.remove("active");
 }
 if(boton8.classList.contains("active")){
    boton8.classList.remove("active");
 }
 if(boton9.classList.contains("active")){
    boton9.classList.remove("active");
 }
 if(boton10.classList.contains("active")){
    boton10.classList.remove("active");
 }
 if(boton11.classList.contains("active")){
    boton11.classList.remove("active");
 }
 if(boton12.classList.contains("active")){
    boton12.classList.remove("active");
 }
});

document.getElementById('boton2').addEventListener("click", function(){
  
    if(!boton2.classList.contains("active")){
       boton2.classList.toggle("active");
    }
   
    if(boton1.classList.contains("active")){
       boton1.classList.remove("active");
    }
    if(boton3.classList.contains("active")){
     boton3.classList.remove("active");
  }
    if(boton4.classList.contains("active")){
     boton4.classList.remove("active");
  }
   if(boton5.classList.contains("active")){
     boton5.classList.remove("active");
  }
  if(boton6.classList.contains("active")){
     boton6.classList.remove("active");
  } 
  if(boton7.classList.contains("active")){
     boton7.classList.remove("active");
  }
  if(boton8.classList.contains("active")){
     boton8.classList.remove("active");
  }
  if(boton9.classList.contains("active")){
     boton9.classList.remove("active");
  }
  if(boton10.classList.contains("active")){
     boton10.classList.remove("active");
  }
  if(boton11.classList.contains("active")){
     boton11.classList.remove("active");
  }
  if(boton12.classList.contains("active")){
     boton12.classList.remove("active");
  }
 });
document.getElementById('boton3').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(!boton3.classList.contains("active")){
      boton3.classList.toggle("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton4').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(!boton4.classList.contains("active")){
      boton4.classList.toggle("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton5').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(!boton5.classList.contains("active")){
      boton5.classList.toggle("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton6').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(!boton6.classList.contains("active")){
      boton6.classList.toggle("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton7').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(!boton7.classList.contains("active")){
      boton7.classList.toggle("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton8').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(!boton8.classList.contains("active")){
      boton8.classList.toggle("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton9').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(!boton9.classList.contains("active")){
      boton9.classList.toggle("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton10').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(!boton10.classList.contains("active")){
      boton10.classList.toggle("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton11').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(!boton11.classList.contains("active")){
      boton11.classList.toggle("active");
   }
   if(boton12.classList.contains("active")){
      boton12.classList.remove("active");
   }
   
 });
 document.getElementById('boton12').addEventListener("click", function(){
  
    if(boton2.classList.contains("active")){
        boton2.classList.remove("active");
     }
    
     if(boton1.classList.contains("active")){
        boton1.classList.remove("active");
     }
     if(boton3.classList.contains("active")){
      boton3.classList.remove("active");
   }
     if(boton4.classList.contains("active")){
      boton4.classList.remove("active");
   }
    if(boton5.classList.contains("active")){
      boton5.classList.remove("active");
   }
   if(boton6.classList.contains("active")){
      boton6.classList.remove("active");
   } 
   if(boton7.classList.contains("active")){
      boton7.classList.remove("active");
   }
   if(boton8.classList.contains("active")){
      boton8.classList.remove("active");
   }
   if(boton9.classList.contains("active")){
      boton9.classList.remove("active");
   }
   if(boton10.classList.contains("active")){
      boton10.classList.remove("active");
   }
   if(boton11.classList.contains("active")){
      boton11.classList.remove("active");
   }
   if(!boton12.classList.contains("active")){
      boton12.classList.toggle("active");
   }
   
 });