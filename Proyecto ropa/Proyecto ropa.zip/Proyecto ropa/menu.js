const app = document.getElementById('typewriter');
const typewriter = new Typewriter(app, {
  loop:true,
  delay:75
});
typewriter
  .typeString('ADA ITS')
  .pauseFor(600)
  .start();