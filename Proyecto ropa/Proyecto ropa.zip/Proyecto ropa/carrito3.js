var boton1 = document.getElementById("boton1");

document.getElementById('boton1').addEventListener("click", function(){
  
   if(!boton1.classList.contains("active")){
      boton1.classList.toggle("active");
   }
  
});