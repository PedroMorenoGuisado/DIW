var boton1 = document.getElementById("boton1");
var boton2 = document.getElementById("boton2");

document.getElementById('boton1').addEventListener("click", function(){
  
   if(boton2.classList.contains("active")){
      boton2.classList.remove("active");
   }
  
   if(!boton1.classList.contains("active")){
      boton1.classList.toggle("active");
   }
  
});

document.getElementById('boton2').addEventListener("click", function(){
  
   if(boton1.classList.contains("active")){
      boton1.classList.remove("active");
   }
   
   if(!boton2.classList.contains("active")){
      boton2.classList.toggle("active");
   }
  
});